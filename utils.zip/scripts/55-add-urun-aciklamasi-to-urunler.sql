ALTER TABLE urunler
ADD COLUMN urun_aciklamasi TEXT;
