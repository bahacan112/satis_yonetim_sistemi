ALTER TABLE public.satislar
DROP COLUMN IF EXISTS bekleme;
