DROP VIEW IF EXISTS public.firma_satis_detaylari_view;
