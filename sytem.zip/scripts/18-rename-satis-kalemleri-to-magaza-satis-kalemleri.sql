-- satis_kalemleri tablosunu magaza_satis_kalemleri olarak yeniden adlandır
ALTER TABLE satis_kalemleri RENAME TO magaza_satis_kalemleri;
