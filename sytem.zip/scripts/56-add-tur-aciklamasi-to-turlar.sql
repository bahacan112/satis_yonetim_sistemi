ALTER TABLE turlar
ADD COLUMN tur_aciklamasi TEXT;
