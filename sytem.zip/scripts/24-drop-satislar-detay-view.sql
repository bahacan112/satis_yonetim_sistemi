DROP VIEW IF EXISTS satislar_detay_view;
