-- Eğer varsa rehber_bildirimleri tablosunu sil
DROP TABLE IF EXISTS rehber_bildirimleri CASCADE;
