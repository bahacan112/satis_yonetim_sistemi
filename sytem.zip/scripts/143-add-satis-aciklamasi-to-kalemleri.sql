ALTER TABLE public.magaza_satis_kalemleri
ADD COLUMN satis_aciklamasi TEXT;

ALTER TABLE public.rehber_satis_kalemleri
ADD COLUMN satis_aciklamasi TEXT;
