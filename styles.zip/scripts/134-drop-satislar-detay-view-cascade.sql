-- scripts/134-drop-satislar-detay-view-cascade.sql
-- Drop satislar_detay_view and all its dependent objects using CASCADE.

DROP VIEW IF EXISTS public.satislar_detay_view CASCADE;
